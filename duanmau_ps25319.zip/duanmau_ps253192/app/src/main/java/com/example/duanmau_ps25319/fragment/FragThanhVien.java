package com.example.duanmau_ps25319.fragment;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;


import com.example.duanmau_ps25319.DAO.DAOTV;
import com.example.duanmau_ps25319.R;

import com.example.duanmau_ps25319.adapter.ThanhVienAdapter;
import com.example.duanmau_ps25319.model.ThanhVien;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class FragThanhVien extends Fragment {
    ListView listView;
    ArrayList<ThanhVien> list;
    Button btnAdd,btnDelete,btnOk,btnDialogDeleteYes,btnDialogDeleteNo;
    TextView tvHide,tvName,tvDate,tvDialogDelete,tvTitleDialog;
    EditText txtName,txtDate;
    Spinner spinner;
    int idThanhvien;
    ThanhVien item;
    ThanhVienAdapter adapter;
    DAOTV daotv;
    View lastTouchView;
    private SimpleDateFormat dfm = new SimpleDateFormat("yyyy-MM-dd");
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // anh xa
        View v = inflater.inflate(R.layout.list_view,container,false);
        btnAdd= v.findViewById(R.id.btnYes);
        btnDelete = v.findViewById(R.id.btnNo);
        lastTouchView=new View(getActivity());
        // set adapter
        listView = v.findViewById(R.id.list_view);
        daotv=new DAOTV(getActivity());
        loadData();
        // click item listview
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // get id thanh vien
                lastTouchView.setBackgroundResource(0);
                view.setBackgroundResource(R.color.pink_1);
                lastTouchView =view;
                item = list.get(position);
                idThanhvien=item.getMaTV();
            }
        });
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
               item=list.get(position);
               idThanhvien=item.getMaTV();
               // cap nhat
                openDialog(1);
                return false;
            }
        });
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // them
                openDialog(0);
            }
        });
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                xoa(idThanhvien);
            }
        });
        return v;
    }
    protected void openDialog(final int type){
        AlertDialog.Builder builder =new AlertDialog.Builder(getContext());
        LayoutInflater inflater =this.getLayoutInflater();
        View v = inflater.inflate(R.layout.add_user,null);
        builder.setView(v);
        Dialog dialog = builder.create();
        dialog.show();
        spinner= v.findViewById(R.id.spinner);spinner.setVisibility(View.GONE);
        tvHide =(TextView) v.findViewById(R.id.txtRole);tvHide.setVisibility(View.GONE);
        tvName = (TextView) v.findViewById(R.id.txtUser);tvName.setText("Tên thành viên");
        txtName = v.findViewById(R.id.txtNewPass);
        tvDate =(TextView) v.findViewById(R.id.txtMk);
        tvDate.setText("Năm sinh");
        txtDate= v.findViewById(R.id.txtRePass);
        txtDate.setInputType(InputType.TYPE_CLASS_TEXT);
        btnOk=v.findViewById(R.id.btnOk);
        btnOk.setText("Đăng ký thành viên");
        if(type !=0){
            btnOk.setText("Cập nhật thành viên");
            txtName.setText(item.getHoTen());
            txtDate.setText(dfm.format(item.getNamSinh()));
        }
        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    item = new ThanhVien();
                    item.setHoTen(txtName.getText().toString());
                    item.setNamSinh(dfm.parse(txtDate.getText().toString()));
                    if(validate()>0){
                        if(type==0){
                            // insert dialog
                            if (daotv.insert(item)) {
                                Toast.makeText(getContext(), "Đăng ký thành công", Toast.LENGTH_SHORT).show();dialog.dismiss();
                                loadData();
                                dialog.dismiss();
                            }else{
                                Toast.makeText(getContext(), "Đăng ký thất bại", Toast.LENGTH_SHORT).show();
                            }
                        }else {
                            // get id thanh vien
                            item.setMaTV(idThanhvien);
                            if(daotv.updateTV(item)){
                                Toast.makeText(getContext(), "Cập nhật thành công", Toast.LENGTH_SHORT).show();
                                loadData();
                                dialog.dismiss();
                            }else{
                                Toast.makeText(getContext(), "Cập nhật thất bại", Toast.LENGTH_SHORT).show();
                            }
                        }

                    }
                }catch (Exception ex){
                    ex.printStackTrace();
                }
            }
            });
        }


    private void loadData(){
        list = daotv.getAll();
        adapter = new ThanhVienAdapter(getActivity(),this,list);
        listView.setAdapter(adapter);
    }
    // dialog xoa
    private void xoa(final int id){
        AlertDialog.Builder builder =new AlertDialog.Builder(getContext());
        LayoutInflater inflater =this.getLayoutInflater();
        View v = inflater.inflate(R.layout.dialog_exit,null);
        builder.setView(v);
        Dialog dialog = builder.create();
        dialog.show();
        tvTitleDialog =(TextView) v.findViewById(R.id.title_dialog);
        tvDialogDelete = (TextView)v.findViewById(R.id.content_dialog);
        btnDialogDeleteYes= v.findViewById(R.id.btnYes);
        btnDialogDeleteNo = v.findViewById(R.id.btnNo);
        tvTitleDialog.setText("Xóa thành viên");
        tvDialogDelete.setText("Bạn đồng ý xóa thành viên này chứ ?");
        btnDialogDeleteNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        btnDialogDeleteYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(daotv.deleteTV(id)){
                    Toast.makeText(getContext(), "Xóa thành công", Toast.LENGTH_SHORT).show();
                    loadData();
                    dialog.dismiss();
                }else{
                    Toast.makeText(getContext(), "Xóa thất bại", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
    // validate
    private int validate(){
        int check =1;
        if(txtName.getText().length() ==0 || txtDate.getText().length() == 0){
            Toast.makeText(getContext(), "Bạn chưa nhập đủ thông tin", Toast.LENGTH_SHORT).show();
            check =-1;
        }
        return check;
    }
}
