package com.example.duanmau_ps25319.fragment;

import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.example.duanmau_ps25319.R;
import com.example.duanmau_ps25319.adapter.AdapterThongKe;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

public class Frag_thongke extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.frag_thongke,container,false);
        TabLayout tabLayout = v.findViewById(R.id.tab_layout);
        ViewPager2 viewPager2 = v.findViewById(R.id.view_pager2);
        AdapterThongKe adapter = new AdapterThongKe(getActivity());
        viewPager2.setAdapter(adapter);
        tabLayout.setBackgroundResource(R.color.pink_2);
        new TabLayoutMediator(tabLayout, viewPager2, new TabLayoutMediator.TabConfigurationStrategy() {
            @Override
            public void onConfigureTab(@NonNull TabLayout.Tab tab, int position) {
                if(position == 0){
                    tab.setText("Top 10");
                }else{
                    tab.setText("Doanh thu");
                }
            }
        }).attach();
        return v;
    }
}
