package com.example.duanmau_ps25319.model;

public class Sach {
    private int maSach;
    private String tenSach;
    private   float tienThue;
    private int maLoai;

    public Sach(){}
    public Sach(int maSach, String tenSach, float tienThue, int maLoai) {
        this.maSach = maSach;
        this.tenSach = tenSach;
        this.tienThue = tienThue;
        this.maLoai = maLoai;
    }

    public int getMaSach() {
        return maSach;
    }

    public void setMaSach(int maSach) {
        this.maSach = maSach;
    }

    public String getTenSach() {
        return tenSach;
    }

    public void setTenSach(String tenSach) {
        this.tenSach = tenSach;
    }

    public float getTienThue() {
        return tienThue;
    }

    public void setTienThue(float tienThue) {
        this.tienThue = tienThue;
    }

    public int getMaLoai() {
        return maLoai;
    }

    public void setMaLoai(int maLoai) {
        this.maLoai = maLoai;
    }

}
