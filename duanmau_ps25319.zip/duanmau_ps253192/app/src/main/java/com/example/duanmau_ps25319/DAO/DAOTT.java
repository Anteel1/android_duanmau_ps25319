package com.example.duanmau_ps25319.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.duanmau_ps25319.database.sqlite;
import com.example.duanmau_ps25319.model.ThuThu;

public class DAOTT {
    private static sqlite sqlite;
    public DAOTT (Context context){
        sqlite = new sqlite(context);
    }
    public boolean dangky(ThuThu tt){
        SQLiteDatabase database = sqlite.getWritableDatabase();
        try{
            ContentValues contentValues = new ContentValues();
            contentValues.put("Role",tt.getRole());
            contentValues.put("TenTT",tt.getTenTT());
            contentValues.put("MatKhau",tt.getMatKhau());
            long values =database.insert("ThuThu",null,contentValues);
            return (values>0);
        }catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
    public boolean checkLogin(String user,String pass){
        boolean check = false;
        SQLiteDatabase database = sqlite.getReadableDatabase();
        try{
            String sql = "Select * from ThuThu ";
            Cursor cs = database.rawQuery(sql,null);
            cs.moveToFirst();
            while(!cs.isAfterLast()){
                int maTT = cs.getInt(0);
                int role = cs.getInt(1);
                String usern = cs.getString(2);
                String passw = cs.getString(3);
                if(usern.equalsIgnoreCase(user) && passw.equalsIgnoreCase(pass)){
                    check = true;
                    break;
                }
                cs.moveToNext();
            }
            database.close();
            cs.close();
            return check;
        }catch (Exception ex){
            ex.printStackTrace();
            return false;
        }
    }
    public static ThuThu getID(String user){
        ThuThu tt = new ThuThu();
        SQLiteDatabase database = sqlite.getReadableDatabase();
        String sql = "Select * from ThuThu where TenTT=?";
        Cursor cs =database.rawQuery(sql,new String[]{user});
        cs.moveToFirst();
        if(cs.getCount()!=0){
            tt.setMaTT(cs.getInt(0));
            tt.setRole(cs.getInt(1));
            tt.setTenTT(cs.getString(2));
            tt.setMatKhau(cs.getString(3));
        }
        database.close();
        cs.close();
        return tt;
    }
    public boolean updatePass(ThuThu TT){
        SQLiteDatabase database = sqlite.getWritableDatabase();
        database.beginTransaction();
        long values=-1;
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put("MatKhau",TT.getMatKhau());
            values= database.update("ThuThu",contentValues,"MaTT=?",
                    new String[]{String.valueOf(TT.getMaTT())});
            database.setTransactionSuccessful();

        }catch (Exception ex){
            ex.printStackTrace();
            return false;
        }finally {
            database.endTransaction();
            return (values>0);
        }
    }

}
