package com.example.duanmau_ps25319.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.duanmau_ps25319.database.sqlite;
import com.example.duanmau_ps25319.model.LoaiSach;
import com.example.duanmau_ps25319.model.ThanhVien;

import java.util.ArrayList;

public class DAOLoaiSach {
    private static sqlite sqlite;
    public DAOLoaiSach(Context context){
        sqlite = new sqlite(context);
    }
    public ArrayList<LoaiSach> getAll (){
        try{
            ArrayList<LoaiSach> list = new ArrayList<>();
            SQLiteDatabase database =sqlite.getReadableDatabase();
            String sql ="Select * from LoaiSach";
            Cursor cs = database.rawQuery(sql,null);
            cs.moveToFirst();
            while (!cs.isAfterLast()){
                list.add(new LoaiSach(cs.getInt(0),cs.getString(1),cs.getInt(2)));
                cs.moveToNext();
            }
            database.close();
            cs.close();
            return list;
        }catch (Exception ex){
            ex.printStackTrace();
            return null;
        }

    }
    public String getnameByid (int maloai){
        try{
            String name="";
            SQLiteDatabase database =sqlite.getReadableDatabase();
            String sql ="Select * from LoaiSach where MaLoai=?";
            Cursor cs = database.rawQuery(sql,new String[]{String.valueOf(maloai)});
            cs.moveToFirst();
            if(cs.getCount()!=0){
                name =cs.getString(1);
            }
            database.close();
            cs.close();
            return name;
        }catch (Exception ex){
            ex.printStackTrace();
            return null;
        }

    }
    public ArrayList<LoaiSach> getAllConhang (){
        try{
            ArrayList<LoaiSach> list = new ArrayList<>();
            SQLiteDatabase database =sqlite.getReadableDatabase();
            String sql ="Select * from LoaiSach where Conhang=?";
            Cursor cs = database.rawQuery(sql,new String[]{String.valueOf(0)});
            cs.moveToFirst();
            while (!cs.isAfterLast()){
             list.add(new LoaiSach(cs.getInt(0),cs.getString(1),cs.getInt(2)));
                cs.moveToNext();
            }
            database.close();
            cs.close();
            return list;
        }catch (Exception ex){
            ex.printStackTrace();
            return null;
        }

    }
    public boolean insert(LoaiSach loaiSach){
        SQLiteDatabase database = sqlite.getWritableDatabase();
        try{
            ContentValues contentValues = new ContentValues();
            contentValues.put("Tenloai",loaiSach.getTenLoai());
            contentValues.put("Conhang",loaiSach.getConHang());
            long values =database.insert("LoaiSach",null,contentValues);
            return (values>0);
        }catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
    public boolean updateLoaiSach(LoaiSach loaiSach){
        SQLiteDatabase database = sqlite.getWritableDatabase();
        database.beginTransaction();
        long values=-1;
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put("Tenloai",loaiSach.getTenLoai());
            contentValues.put("Conhang",loaiSach.getConHang());
            values= database.update("LoaiSach",contentValues,"Maloai =?",
                    new String[]{String.valueOf(loaiSach.getMaLoai())});
            database.setTransactionSuccessful();

        }catch (Exception ex){
            ex.printStackTrace();
            return false;
        }finally {
            database.endTransaction();
            return (values>0);
        }
    }
    public boolean deleteLoaisach(int maLoai){
        SQLiteDatabase database = sqlite.getWritableDatabase();
        boolean check = false;
        try{
            database.delete("LoaiSach","Maloai=?",new String[]{String.valueOf(maLoai)});
            check = true;
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return check;
    }
}
