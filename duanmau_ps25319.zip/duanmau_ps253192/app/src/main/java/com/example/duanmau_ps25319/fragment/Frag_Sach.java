package com.example.duanmau_ps25319.fragment;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.duanmau_ps25319.DAO.DAOLoaiSach;
import com.example.duanmau_ps25319.DAO.DAOSach;
import com.example.duanmau_ps25319.R;
import com.example.duanmau_ps25319.adapter.AdapterSpinnerLoaiSach;
import com.example.duanmau_ps25319.adapter.LoaiSachAdapter;
import com.example.duanmau_ps25319.adapter.SachAdapter;
import com.example.duanmau_ps25319.model.LoaiSach;
import com.example.duanmau_ps25319.model.Sach;

import java.util.ArrayList;

public class Frag_Sach extends Fragment {
    ListView listView;
    EditText txtTenSach,txtienThue;
    TextView tvTitleDialog,tvDialogDelete;
    ArrayList<Sach> list;
    Sach item;
    int idSach,idMaLoai;
    Button btnOk,btnAdd,btnDelete,btnDialogDeleteYes,btnDialogDeleteNo;
    SachAdapter adapter;
    Spinner spinnerLoaiSach;
    View lastTouchView;
    static DAOSach daoSach;
    DAOLoaiSach daoLoaiSach;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v =inflater.inflate(R.layout.list_view,container,false);
        lastTouchView=new View(getActivity());
        btnAdd = v.findViewById(R.id.btnYes);
        btnDelete = v.findViewById(R.id.btnNo);
        daoSach = new DAOSach(getActivity());
        daoLoaiSach = new DAOLoaiSach(getActivity());
        listView= v.findViewById(R.id.list_view);
        // set data
        loadData();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                lastTouchView.setBackgroundResource(0);
                view.setBackgroundResource(R.color.pink_1);
                lastTouchView =view;
                item = list.get(position);
                idSach=item.getMaSach();
                Log.d("item",item.getMaLoai()+" "+item.getTenSach()+" "+item.getMaLoai());
            }
        });
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                item = list.get(position);
                idSach=item.getMaSach();
                openDialog(1);
                return false;
            }
        });
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog(0);
            }
        });
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              xoa(idSach);
            }
        });
        return v;
    }
    private void xoa(final int id){
        AlertDialog.Builder builder =new AlertDialog.Builder(getContext());
        LayoutInflater inflater =this.getLayoutInflater();
        View v = inflater.inflate(R.layout.dialog_exit,null);
        builder.setView(v);
        Dialog dialog = builder.create();
        dialog.show();
        tvTitleDialog =(TextView) v.findViewById(R.id.title_dialog);
        tvDialogDelete = (TextView)v.findViewById(R.id.content_dialog);
        btnDialogDeleteYes= v.findViewById(R.id.btnYes);
        btnDialogDeleteNo = v.findViewById(R.id.btnNo);
        tvTitleDialog.setText("Xóa sách");
        tvDialogDelete.setText("Bạn đồng ý xóa sách này chứ ?");
        btnDialogDeleteNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        btnDialogDeleteYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if( daoSach.deleteLoaisach(idSach)){
                    Toast.makeText(getContext(), "Xóa thành công", Toast.LENGTH_SHORT).show();
                    loadData();
                }else{
                    Toast.makeText(getContext(), "Xóa thất bại", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    protected void openDialog(final int type){
        AlertDialog.Builder builder =new AlertDialog.Builder(getContext());
        LayoutInflater inflater =this.getLayoutInflater();
        View v = inflater.inflate(R.layout.layout_addsach,null);
        builder.setView(v);
        Dialog dialog = builder.create();
        dialog.show();
        txtTenSach = dialog.findViewById(R.id.txtTenSach);
        txtienThue = dialog.findViewById(R.id.txtTienThue);
        spinnerLoaiSach = dialog.findViewById(R.id.spinner);
        ArrayList<LoaiSach> list1= daoLoaiSach.getAllConhang();
        AdapterSpinnerLoaiSach spnAdapter = new AdapterSpinnerLoaiSach(getContext(),list1);
        spinnerLoaiSach.setAdapter(spnAdapter);
        btnOk=v.findViewById(R.id.btnOk);
        btnOk.setText("Thêm sách");
        spinnerLoaiSach.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                idMaLoai= list1.get(position).getMaLoai();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        if(type !=0){
            btnOk.setText("Cập nhật sách");
            txtTenSach.setText(item.getTenSach());
            txtienThue.setText(String.valueOf(item.getTienThue()));
            spinnerLoaiSach.setSelection(item.getMaLoai()-1);
        }
        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    item = new Sach();
                    item.setTenSach(txtTenSach.getText().toString());
                    item.setTienThue(Float.parseFloat(txtienThue.getText().toString()));
                    item.setMaLoai(idMaLoai);
                    if(validate()>0){
                        if(type==0){
                            // insert dialog
                            if (daoSach.insert(item)) {
                                Toast.makeText(getContext(), "Thêm thành công", Toast.LENGTH_SHORT).show();dialog.dismiss();
                                loadData();
                                dialog.dismiss();
                            }else{
                                Toast.makeText(getContext(), "Thêm thất bại", Toast.LENGTH_SHORT).show();
                            }
                        }else {
                            // get id thanh vien
                            item.setMaSach(idSach);
                            if(daoSach.updateSach(item)){
                                Toast.makeText(getContext(), "Cập nhật thành công", Toast.LENGTH_SHORT).show();
                                loadData();
                                dialog.dismiss();
                            }else{
                                Toast.makeText(getContext(), "Cập nhật thất bại", Toast.LENGTH_SHORT).show();
                            }
                        }

                    }
                }catch (Exception ex){
                    ex.printStackTrace();
                }
            }
        });
    }
    private int validate(){
        int check =1;
        if(txtTenSach.getText().length() ==0){
            Toast.makeText(getContext(), "Bạn chưa nhập đủ thông tin", Toast.LENGTH_SHORT).show();
            check =-1;
        }
        return check;
    }
    private void loadData(){
        list = daoSach.getAll();
        adapter = new SachAdapter(getActivity(),this,list);
        listView.setAdapter(adapter);
    }
}
