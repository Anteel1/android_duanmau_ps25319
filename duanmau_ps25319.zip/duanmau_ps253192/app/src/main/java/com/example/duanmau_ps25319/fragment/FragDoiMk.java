package com.example.duanmau_ps25319.fragment;

import static android.content.Context.MODE_PRIVATE;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.duanmau_ps25319.DAO.DAOTT;
import com.example.duanmau_ps25319.R;
import com.example.duanmau_ps25319.model.ThuThu;
import com.google.android.material.textfield.TextInputEditText;

public class FragDoiMk extends Fragment {
    TextInputEditText txtPass,txtNewPass,txtRePass;
    Button btnOk;
    SharedPreferences preferences;
    DAOTT dao;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
       View v = inflater.inflate(R.layout.doi_matkhau,container,false);
       txtPass = v.findViewById(R.id.txtPass);
       txtNewPass = v.findViewById(R.id.txtNewPass);
       txtRePass = v.findViewById(R.id.txtRePass);
       btnOk = v.findViewById(R.id.btnOk);
       dao = new DAOTT(getContext());
       preferences= getActivity().getSharedPreferences("Profile_user", MODE_PRIVATE);
       String user = preferences.getString("user","");

       // button change pass
       btnOk.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               if(validate()>0){
                   ThuThu tt= dao.getID(user);
                   Log.d("User name:",tt.getTenTT()+" mat khau:"+tt.getMatKhau());
                   tt.setMatKhau(txtNewPass.getText().toString());
                   if(dao.updatePass(tt)){
                       Toast.makeText(getContext(), "Đổi thành công", Toast.LENGTH_SHORT).show();
                       txtPass.setText("");
                       txtNewPass.setText("");
                       txtRePass.setText("");
                   }else{
                       Toast.makeText(getContext(), "Đổi thất bại", Toast.LENGTH_SHORT).show();
                   }
               }
           }
       });
        return v;
    }
    // validate form
    private int validate(){
        int check = 1;
        if(txtPass.getText().length() ==0 || txtNewPass.getText().length() == 0 || txtRePass.getText().length() ==0){
            Toast.makeText(getContext(), "Bạn phải nhập đủ thông tin", Toast.LENGTH_SHORT).show();
            check = -1;
        }else{
            preferences = getActivity().getSharedPreferences("Profile_user",MODE_PRIVATE);
            String passOld = preferences.getString("pass","");
            String newPass = txtNewPass.getText().toString();
            String rePass = txtRePass.getText().toString();
            if(!passOld.equals(txtPass.getText().toString())){
                Toast.makeText(getContext(), "Mật khẩu cũ sai", Toast.LENGTH_SHORT).show();
                check = -1;
            }
            if(!newPass.equals(rePass)){
                Toast.makeText(getContext(), "Mật khẩu phải trùng nhau", Toast.LENGTH_SHORT).show();
                check = -1;
            }
        }
        return check;
    }
}
