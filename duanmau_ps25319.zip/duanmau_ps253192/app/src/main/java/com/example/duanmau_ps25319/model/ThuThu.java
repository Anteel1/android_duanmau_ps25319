package com.example.duanmau_ps25319.model;

public class ThuThu {
    private int maTT;
    private int role;
    private String tenTT;
    private String matKhau;
    public ThuThu(){
    }
    public ThuThu(int maTT, int role, String tenTT, String matKhau) {
        this.maTT = maTT;
        this.role = role;
        this.tenTT = tenTT;
        this.matKhau = matKhau;
    }

    public ThuThu(int role, String tenTT, String matKhau) {
        this.role = role;
        this.tenTT = tenTT;
        this.matKhau = matKhau;
    }

    public ThuThu(String tenTT, String matKhau) {
        this.tenTT = tenTT;
        this.matKhau = matKhau;
    }

    public int getMaTT() {
        return maTT;
    }

    public void setMaTT(int maTT) {
        this.maTT = maTT;
    }

    public int getRole() {
        return role;
    }

    public void setRole(int role) {
        this.role = role;
    }

    public String getTenTT() {
        return tenTT;
    }

    public void setTenTT(String tenTT){
        this.tenTT = tenTT;
    }

    public String getMatKhau() {
        return matKhau;
    }

    public void setMatKhau(String matKhau) {
        this.matKhau = matKhau;
    }
}
