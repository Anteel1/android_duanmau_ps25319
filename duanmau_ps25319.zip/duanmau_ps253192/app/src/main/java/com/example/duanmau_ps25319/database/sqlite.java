package com.example.duanmau_ps25319.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class sqlite extends SQLiteOpenHelper {
    public  sqlite (Context ct){
        super(ct,"MyDb",null,4);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableLoaiSach ="Create table LoaiSach(Maloai integer primary key autoincrement,"+
                "Tenloai text,Conhang integer)";
        db.execSQL(createTableLoaiSach);
        String createTableSach ="Create table Sach(MaSach integer primary key autoincrement,"+
                "TenSach text,Tienthue float,"
                +"Maloai int references LoaiSach(Maloai))";
        db.execSQL(createTableSach);
        String createTableThanhVien ="Create table ThanhVien(MaTV integer primary key autoincrement,"+
                "TenTV text,NamSinh date)";
        db.execSQL(createTableThanhVien);
        String createTableThuThu ="Create table ThuThu(MaTT integer primary key autoincrement,"+
                "Role integer,TenTT text,MatKhau text)";
        db.execSQL(createTableThuThu);
        String createTablePhieuMuon ="Create table PhieuMuon(MaPM integer primary key autoincrement,"+
                "MaTV integer references ThanhVien(MaTV),"
                +"MaSach integer references Sach(MaSach),"
                +"MaTT text references ThuThu(MaTT),"
                +"Tienthue float, Ngaythue date,Ngaytra integer)";
        db.execSQL(createTablePhieuMuon);
        String dulieumau = "insert into ThuThu values (1,1,'TT01','123')";
        db.execSQL(dulieumau);
        dulieumau = "insert into ThuThu values (2,2,'TT02','123')";
        db.execSQL(dulieumau);
        dulieumau = "insert into ThuThu values (3,2,'TT03','123')";
        db.execSQL(dulieumau);
        dulieumau = "insert into ThanhVien values (1,'Nguyen Van A','2000-07-07')";
        db.execSQL(dulieumau);
        dulieumau = "insert into ThanhVien values (2,'Nguyen Van B','2001-07-07')";
        db.execSQL(dulieumau);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if(oldVersion != newVersion){
            db.execSQL("Drop table if exists LoaiSach");
            db.execSQL("Drop table if exists Sach");
            db.execSQL("Drop table if exists ThanhVien");
            db.execSQL("Drop table if exists ThuThu");
            db.execSQL("Drop table if exists PhieuMuon");
            onCreate(db);
        }


    }
}
