package com.example.duanmau_ps25319.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.duanmau_ps25319.DAO.DAOTT;
import com.example.duanmau_ps25319.R;
import com.example.duanmau_ps25319.model.ThuThu;

public class Frag_taoUser extends Fragment {
    EditText txtTenTk,txtPass;
    Spinner spinner;
    Button btnOk;
    static DAOTT daott;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.add_user,container,false);
        btnOk = v.findViewById(R.id.btnOk);btnOk.setText("Đăng ký");
        spinner = v.findViewById(R.id.spinner);
        txtTenTk= v.findViewById(R.id.txtNewPass);
        txtPass = v.findViewById(R.id.txtRePass);
        daott = new DAOTT(getContext());
        // spinner
        String[] status= {"Admin","Thủ thư"} ;
        ArrayAdapter<String> spnAdapter = new ArrayAdapter<>(getContext(),android.R.layout.simple_list_item_1,status);
        spinner.setAdapter(spnAdapter);
        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validate()>0){
                    ThuThu tt = new ThuThu();
                    if(((String)spinner.getSelectedItem()).equals("Admin")){
                        tt.setRole(1);
                    }else{
                        tt.setRole(2);
                    }
                    tt.setTenTT(txtTenTk.getText().toString());
                    tt.setMatKhau(txtPass.getText().toString());
                    if(daott.dangky(tt)){
                        spinner.setSelection(0);
                        txtTenTk.setText("");
                        txtPass.setText("");
                        Toast.makeText(getContext(), "Đăng ký thành công", Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(getContext(), "Đăng ký thất bại", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        return v;
    }
    private int validate(){
        int check = 1;
        // validate rong
            if( txtTenTk.getText().toString().isEmpty()|| txtPass.getText().toString().isEmpty()){
                Toast.makeText(getContext(), "Không được để trống", Toast.LENGTH_SHORT).show();
                check = -1;
            }
            // check user trung
         if((txtTenTk.getText().toString()).equals((daott.getID(txtTenTk.getText().toString()).getTenTT()))){
             Toast.makeText(getContext(), "Tên tài khoản đã trùng", Toast.LENGTH_SHORT).show();
             check = -1;
         }
        return check;
    }
}
