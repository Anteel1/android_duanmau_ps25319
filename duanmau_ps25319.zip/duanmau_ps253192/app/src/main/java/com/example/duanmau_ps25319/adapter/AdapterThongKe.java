package com.example.duanmau_ps25319.adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.duanmau_ps25319.fragment.Frag_thongkeDoanhThu;
import com.example.duanmau_ps25319.fragment.Frag_thongketop10;

public class AdapterThongKe extends FragmentStateAdapter {

    public AdapterThongKe(@NonNull FragmentActivity fragmentActivity){
        super(fragmentActivity);
    }
    @NonNull
    @Override
    public Fragment createFragment(int position) {
        if(position ==0){
            return new Frag_thongketop10();
        }else{
            return new Frag_thongkeDoanhThu();
        }
    }

    @Override
    public int getItemCount() {
        return 2;
    }
}
