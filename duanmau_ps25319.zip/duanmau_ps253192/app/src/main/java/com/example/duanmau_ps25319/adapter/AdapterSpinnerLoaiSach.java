package com.example.duanmau_ps25319.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.duanmau_ps25319.R;
import com.example.duanmau_ps25319.model.LoaiSach;

import java.util.ArrayList;

public class AdapterSpinnerLoaiSach extends ArrayAdapter<LoaiSach> {
    private Context context;
    private ArrayList<LoaiSach> list;
    TextView tvTenLoai,tvStatus;

    public AdapterSpinnerLoaiSach(@NonNull Context context, ArrayList<LoaiSach> list) {
        super(context, 0,list);
        this.context = context;
        this.list = list;
    }
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View v = convertView;
        if(v==null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v =inflater.inflate(R.layout.layout_spinnerloaisach,null);
        }
        LoaiSach item = list.get(position);
        if(item !=null){
            tvTenLoai = v.findViewById(R.id.tvTenLoai);
            tvStatus = v.findViewById(R.id.tvStatus);
            tvTenLoai.setText(item.getTenLoai());
            if(item.getConHang() ==0){
                tvStatus.setText("Còn hàng");
            }else{
                tvStatus.setText("Hết hàng");
            }
        }
        return v;
    }
    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View v = convertView;
        if(v==null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v =inflater.inflate(R.layout.layout_spinnerloaisach,null);
        }
         LoaiSach item = list.get(position);
        if(item !=null){
            tvTenLoai = v.findViewById(R.id.tvTenLoai);
            tvStatus = v.findViewById(R.id.tvStatus);
            tvTenLoai.setText(item.getTenLoai());
            if(item.getConHang() ==0){
                tvStatus.setText("Còn hàng");
            }else{
                tvStatus.setText("Hết hàng");
            }
        }
        return v;
    }
}
