package com.example.duanmau_ps25319.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.duanmau_ps25319.database.sqlite;
import com.example.duanmau_ps25319.model.ThanhVien;
import com.example.duanmau_ps25319.model.ThuThu;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class DAOTV {
    private static sqlite sqlite;
    private SimpleDateFormat dfm = new SimpleDateFormat("yyyy-MM-dd");
    public DAOTV (Context context){
        sqlite = new sqlite(context);
    }
    public  String getNamebyId(int id){
        String name= "";
        try{
            SQLiteDatabase database = sqlite.getReadableDatabase();
            Cursor cs = database.rawQuery("Select * from ThanhVien where MaTV=?",new String[]{String.valueOf(id)});
        cs.moveToFirst();
            if(cs.getCount()!=0){
               name= cs.getString(1);
            }
            database.close();
            cs.close();
            return name;
        }catch (Exception ex){
            ex.printStackTrace();
            return "";
        }

    }
    public ArrayList<ThanhVien> getAll (){
        try{
        ArrayList<ThanhVien> list = new ArrayList<>();
        SQLiteDatabase database =sqlite.getReadableDatabase();
        String sql ="Select * from ThanhVien";
        Cursor cs = database.rawQuery(sql,null);
        cs.moveToFirst();
        while (!cs.isAfterLast()){
            list.add(new ThanhVien(cs.getInt(0),cs.getString(1),dfm.parse(cs.getString(2))));
            cs.moveToNext();
        }
            database.close();
            cs.close();
            return list;
        }catch (Exception ex){
            ex.printStackTrace();
            return null;
        }

    }
    public boolean insert(ThanhVien thanhVien){
        SQLiteDatabase database = sqlite.getWritableDatabase();
        try{
            ContentValues contentValues = new ContentValues();
            contentValues.put("TenTV",thanhVien.getHoTen());
            contentValues.put("NamSinh",dfm.format(thanhVien.getNamSinh()));
            long values =database.insert("ThanhVien",null,contentValues);
            return (values>0);
        }catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
    public boolean updateTV(ThanhVien TV){
        SQLiteDatabase database = sqlite.getWritableDatabase();
        database.beginTransaction();
        long values=-1;
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put("TenTV",TV.getHoTen());
            contentValues.put("NamSinh",dfm.format(TV.getNamSinh()));
            values= database.update("ThanhVien",contentValues,"MaTV =?",
                    new String[]{String.valueOf(TV.getMaTV())});
            database.setTransactionSuccessful();

        }catch (Exception ex){
            ex.printStackTrace();
            return false;
        }finally {
            database.endTransaction();
            return (values>0);
        }
    }
    public boolean deleteTV(int maTV){
        SQLiteDatabase database = sqlite.getWritableDatabase();
        boolean check = false;
        try{
            database.delete("ThanhVien","MaTV=?",new String[]{String.valueOf(maTV)});
            check = true;
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return check;
    }
}
