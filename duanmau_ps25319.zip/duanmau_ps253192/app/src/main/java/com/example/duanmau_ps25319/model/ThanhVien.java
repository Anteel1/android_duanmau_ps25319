package com.example.duanmau_ps25319.model;

import java.util.Date;

public class ThanhVien {
    private int maTV;
    private  String hoTen;
    private Date namSinh;
    public ThanhVien(){}
    public ThanhVien(int maTV, String hoTen, Date namSinh) {
        this.maTV = maTV;
        this.hoTen = hoTen;
        this.namSinh = namSinh;
    }

    public int getMaTV() {
        return maTV;
    }

    public void setMaTV(int maTV) {
        this.maTV = maTV;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public Date getNamSinh() {
        return namSinh;
    }

    public void setNamSinh(Date namSinh) {
        this.namSinh = namSinh;
    }
}
