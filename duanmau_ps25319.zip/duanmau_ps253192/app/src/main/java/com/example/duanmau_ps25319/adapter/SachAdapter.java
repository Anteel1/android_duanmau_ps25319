package com.example.duanmau_ps25319.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.duanmau_ps25319.DAO.DAOLoaiSach;
import com.example.duanmau_ps25319.R;
import com.example.duanmau_ps25319.fragment.Frag_Sach;
import com.example.duanmau_ps25319.model.LoaiSach;
import com.example.duanmau_ps25319.model.Sach;

import java.util.ArrayList;

public class SachAdapter extends ArrayAdapter<Sach> {
    private Context context;
    Frag_Sach fragment;
    private ArrayList<Sach> list;
    TextView tvTenSach,tvLoaisach,tvTenThue;
    DAOLoaiSach daoLoaiSach;
    public SachAdapter(@NonNull Context context,Frag_Sach fragment , ArrayList<Sach> list){
        super(context,0,list);
        this.context = context;
        this.list= list;
        this.fragment = fragment;
        daoLoaiSach = new DAOLoaiSach(context);
    }
    public SachAdapter(@NonNull Context context, ArrayList<Sach> list){
        super(context,0,list);
        this.context = context;
        this.list= list;
        daoLoaiSach = new DAOLoaiSach(context);
    }
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View v= convertView;
        if(v==null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v =inflater.inflate(R.layout.item_sach,null);
        }
        final Sach item = list.get(position);
        if(item !=null){
            tvTenSach = v.findViewById(R.id.tvTenSach);
            tvLoaisach = v.findViewById(R.id.tvLoaiSach);
            tvTenThue = v.findViewById(R.id.tvTienThue);
            tvTenSach.setText(item.getTenSach());
            tvTenThue.setText(String.valueOf(item.getTienThue()));
            tvLoaisach.setText(daoLoaiSach.getnameByid(item.getMaLoai()));
        }
        return v;
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View v= convertView;
        if(v==null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v =inflater.inflate(R.layout.item_sach,null);
        }
        final Sach item = list.get(position);
        if(item !=null){
            tvTenSach = v.findViewById(R.id.tvTenSach);
            tvLoaisach = v.findViewById(R.id.tvLoaiSach);
            tvTenThue = v.findViewById(R.id.tvTienThue);
            tvTenSach.setText(item.getTenSach());
            tvTenThue.setText(String.valueOf(item.getTienThue()));
            tvLoaisach.setText(daoLoaiSach.getnameByid(item.getMaLoai()));
        }
        return v;
    }
}
