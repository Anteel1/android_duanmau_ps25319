package com.example.duanmau_ps25319.fragment;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.example.duanmau_ps25319.R;
import com.example.duanmau_ps25319.views.Login_Activity;


public class Frag_dialog_exit extends DialogFragment {
    Button dialogYes,dialogNo;
    Dialog dialog;
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        dialog = new Dialog(getContext());
        dialog.setContentView(R.layout.dialog_exit);
        dialogYes = (Button) dialog.findViewById(R.id.btnYes);
        dialogNo = (Button) dialog.findViewById(R.id.btnNo);
        dialogYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(), Login_Activity.class));
            }
        });
        dialogNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
        return dialog;
    }
    public static String TAG ="Exit";
}
