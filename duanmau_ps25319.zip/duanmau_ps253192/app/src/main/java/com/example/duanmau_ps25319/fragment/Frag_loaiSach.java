package com.example.duanmau_ps25319.fragment;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.duanmau_ps25319.DAO.DAOLoaiSach;
import com.example.duanmau_ps25319.R;
import com.example.duanmau_ps25319.adapter.LoaiSachAdapter;

import com.example.duanmau_ps25319.model.LoaiSach;



import java.util.ArrayList;


public class Frag_loaiSach extends Fragment {
    ListView listView;
    EditText txtTen;
    ArrayList<LoaiSach> list;
    LoaiSach item;
    int idLoaiSach;
    Button btnOk,btnAdd,btnUpdate;
    LoaiSachAdapter adapter;
    Spinner spinner;
    View lastTouchView;
    static DAOLoaiSach daoLoaiSach;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
       View v = inflater.inflate(R.layout.list_view,container,false);
        // anh xa
        lastTouchView=new View(getActivity());
        btnAdd = v.findViewById(R.id.btnYes);
        btnUpdate = v.findViewById(R.id.btnNo);
        btnUpdate.setText("Cập nhật");
        daoLoaiSach = new DAOLoaiSach(getActivity());
        listView= v.findViewById(R.id.list_view);
        loadData();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // get id thanh vien
                lastTouchView.setBackgroundResource(0);
                view.setBackgroundResource(R.color.pink_1);
                lastTouchView =view;
                item = list.get(position);
                idLoaiSach=item.getMaLoai();
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // them
                openDialog(0);
            }
        });
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog(1);
            }
        });
        return v;
    }
    protected void openDialog(final int type){
        AlertDialog.Builder builder =new AlertDialog.Builder(getContext());
        LayoutInflater inflater =this.getLayoutInflater();
        View v = inflater.inflate(R.layout.layout_loaisach,null);
        builder.setView(v);
        Dialog dialog = builder.create();
        dialog.show();
        txtTen = dialog.findViewById(R.id.txtTenLoai);
        spinner = dialog.findViewById(R.id.spinner);
        String[] status= {"Available","Unavailable"} ;
        ArrayAdapter<String> spnAdapter = new ArrayAdapter<>(getContext(),android.R.layout.simple_list_item_1,status);
        spinner.setAdapter(spnAdapter);
        btnOk=v.findViewById(R.id.btnOk);
        btnOk.setText("Thêm loại sách");
        if(type !=0){
            btnOk.setText("Cập nhật loại sách");
            txtTen.setText(item.getTenLoai());
            spinner.setSelection(item.getConHang());
        }
        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    item = new LoaiSach();
                    item.setTenLoai(txtTen.getText().toString());
                    if((spinner.getSelectedItem()).equals("Available")){
                        item.setConHang(0);
                    }else{
                        item.setConHang(1);
                    }
                    if(validate()>0){
                        if(type==0){
                            // insert dialog
                            if (daoLoaiSach.insert(item)) {
                                Toast.makeText(getContext(), "Thêm thành công", Toast.LENGTH_SHORT).show();dialog.dismiss();
                                loadData();
                                dialog.dismiss();
                            }else{
                                Toast.makeText(getContext(), "Thêm thất bại", Toast.LENGTH_SHORT).show();
                            }
                        }else {
                            // get id thanh vien
                            item.setMaLoai(idLoaiSach);
                            if(daoLoaiSach.updateLoaiSach(item)){
                                Toast.makeText(getContext(), "Cập nhật thành công", Toast.LENGTH_SHORT).show();
                                loadData();
                                dialog.dismiss();
                            }else{
                                Toast.makeText(getContext(), "Cập nhật thất bại", Toast.LENGTH_SHORT).show();
                            }
                        }

                    }
                }catch (Exception ex){
                    ex.printStackTrace();
                }
            }
        });
    }
    private int validate(){
        int check =1;
        if(txtTen.getText().length() ==0){
            Toast.makeText(getContext(), "Bạn chưa nhập đủ thông tin", Toast.LENGTH_SHORT).show();
            check =-1;
        }
        return check;
    }

    private void loadData(){
        list = daoLoaiSach.getAll();
        adapter = new LoaiSachAdapter(getActivity(),this,list);
        listView.setAdapter(adapter);
    }
}
