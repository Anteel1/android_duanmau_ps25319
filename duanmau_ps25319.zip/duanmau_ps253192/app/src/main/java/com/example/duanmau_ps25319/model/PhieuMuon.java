package com.example.duanmau_ps25319.model;

import java.util.Date;

public class PhieuMuon {
    int maPM;
    int maTV;
    int maSach;
    int maTT;
    float tienThue;
    Date ngaythue;
    int ngaytra;
    public PhieuMuon (){}
    public int getMaPM() {
        return maPM;
    }

    public void setMaPM(int maPM) {
        this.maPM = maPM;
    }

    public int getMaTV() {
        return maTV;
    }

    public void setMaTV(int maTV) {
        this.maTV = maTV;
    }

    public int getMaSach() {
        return maSach;
    }

    public void setMaSach(int maSach) {
        this.maSach = maSach;
    }

    public int getMaTT() {
        return maTT;
    }

    public void setMaTT(int maTT) {
        this.maTT = maTT;
    }

    public float getTienThue() {
        return tienThue;
    }

    public void setTienThue(float tienThue) {
        this.tienThue = tienThue;
    }

    public Date getNgaythue() {
        return ngaythue;
    }

    public void setNgaythue(Date ngaythue) {
        this.ngaythue = ngaythue;
    }

    public int getNgaytra() {
        return ngaytra;
    }

    public void setNgaytra(int ngaytra) {
        this.ngaytra = ngaytra;
    }

    public PhieuMuon(int maPM, int maTV, int maSach, int maTT, float tienThue, Date ngaythue, int ngaytra) {
        this.maPM = maPM;
        this.maTV = maTV;
        this.maSach = maSach;
        this.maTT = maTT;
        this.tienThue = tienThue;
        this.ngaythue = ngaythue;
        this.ngaytra = ngaytra;
    }
}
