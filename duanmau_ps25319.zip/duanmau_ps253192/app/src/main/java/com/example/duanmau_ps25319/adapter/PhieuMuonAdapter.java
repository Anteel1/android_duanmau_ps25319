package com.example.duanmau_ps25319.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.duanmau_ps25319.DAO.DAOSach;
import com.example.duanmau_ps25319.DAO.DAOTV;
import com.example.duanmau_ps25319.R;
import com.example.duanmau_ps25319.fragment.Frag_PhieuMuon;
import com.example.duanmau_ps25319.model.PhieuMuon;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class PhieuMuonAdapter extends ArrayAdapter<PhieuMuon> {
    private Context context;
    Frag_PhieuMuon fragment;
    TextView tvTenTV,tvTienThue,tvNgayTra;
    private ArrayList<PhieuMuon>list;
    DAOTV daotv;
    DAOSach daoSach;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    public PhieuMuonAdapter(@NonNull Context context,Frag_PhieuMuon fragment,ArrayList<PhieuMuon>list) {
        super(context, 0,list);
        this.context = context;
        this.fragment=fragment;
        this.list=list;
        daotv = new DAOTV(context);
        daoSach = new DAOSach(context);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View v = convertView;
        if(v==null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v=inflater.inflate(R.layout.item_phieumuon,null);
        }
        final PhieuMuon item = list.get(position);
        if(item !=null){
            tvTenTV = v.findViewById(R.id.tvTenTV);
            tvTienThue= v.findViewById(R.id.tvTienThue);
            tvNgayTra= v.findViewById(R.id.tvNgayTra);
            tvTenTV.setText(daotv.getNamebyId(item.getMaTV()));
            tvTienThue.setText(String.valueOf(item.getTienThue()));
            if(item.getNgaytra() ==0){
                tvNgayTra.setText("Chưa trả sách");
            }else{
                tvNgayTra.setText("Đã trả");
            }
        }
        return v;
    }
}
