package com.example.duanmau_ps25319.views;


import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.example.duanmau_ps25319.DAO.DAOTT;
import com.example.duanmau_ps25319.R;
import com.example.duanmau_ps25319.fragment.FragDoiMk;
import com.example.duanmau_ps25319.fragment.FragThanhVien;
import com.example.duanmau_ps25319.fragment.Frag_PhieuMuon;
import com.example.duanmau_ps25319.fragment.Frag_Sach;
import com.example.duanmau_ps25319.fragment.Frag_dialog_exit;
import com.example.duanmau_ps25319.fragment.Frag_loaiSach;
import com.example.duanmau_ps25319.fragment.Frag_taoUser;
import com.example.duanmau_ps25319.fragment.Frag_thongke;
import com.example.duanmau_ps25319.model.ThuThu;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity {
    Toolbar toolbar;
    DrawerLayout drawer;
    Fragment fragment = null;
    SharedPreferences preferences;
    TextView txtRole;
   static  DAOTT daott;
    ThuThu tt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // share preferences
        preferences= MainActivity.this.getSharedPreferences("Profile_user", MODE_PRIVATE);
        // get role user
        String user = preferences.getString("user","");
        daott = new DAOTT(MainActivity.this);
        Log.d("User Share",user);
        tt = daott.getID(user);
        Log.d("User id:",tt.getTenTT());
        int role = tt.getRole();
        // toolbar
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        // drawer
        drawer = findViewById(R.id.drawer);
        NavigationView nav = findViewById(R.id.navigation_bar);
        // set quyen theo role user
        nav.getMenu().findItem(R.id.taoTK).setVisible(role == 1);
        txtRole = nav.getHeaderView(0).findViewById(R.id.txtRole);
        if(role != 1){
            txtRole.setText("Thủ Thư");
        }
        //icon drawer
        ActionBarDrawerToggle drawerToggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(drawerToggle);
        drawerToggle.syncState();
        //navigation action
        nav.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.qli_sach:
                        fragment = new Frag_Sach();
                        onRestoreInstanceState(savedInstanceState);
                        break;
                    case R.id.qli_theloai:
                        fragment = new Frag_loaiSach();
                        onRestoreInstanceState(savedInstanceState);
                        break;
                    case R.id.ql_PM:
                        fragment = new Frag_PhieuMuon();
                        onRestoreInstanceState(savedInstanceState);
                        break;
                    case R.id.qli_TV:
                        fragment = new FragThanhVien();
                        onRestoreInstanceState(savedInstanceState);
                        break;
                    case R.id.taoTK:
                        fragment = new Frag_taoUser();
                        onRestoreInstanceState(savedInstanceState);
                        break;
                    case R.id.thongke:
                        fragment = new Frag_thongke();
                        onRestoreInstanceState(savedInstanceState);
                        break;
                    case R.id.doiMatKhau:
                        fragment = new FragDoiMk();
                        onRestoreInstanceState(savedInstanceState);
                        break;
                    case R.id.exit:
                        new Frag_dialog_exit().show(getSupportFragmentManager(),Frag_dialog_exit.TAG);
                        break;
                }
                drawer.setSelected(true);
                setTitle(item.getTitle());
                drawer.closeDrawer(GravityCompat.START);
                return true;
            }
        });
    }
    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().
                    add(R.id.fragment_view, fragment).commit();
        }
        else {
            getSupportFragmentManager().beginTransaction().
                    replace(R.id.fragment_view, fragment).commit();
        }
    }
}
