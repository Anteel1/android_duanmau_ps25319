package com.example.duanmau_ps25319.views;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.duanmau_ps25319.DAO.DAOTT;
import com.example.duanmau_ps25319.R;
import com.example.duanmau_ps25319.model.ThuThu;

import java.util.ArrayList;

public class Login_Activity extends AppCompatActivity {
    static DAOTT daott;
    EditText txtUser,txtPass;
    Button btnLogin;
    CheckBox chk_login;
    boolean passwordVisible;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        txtUser = findViewById(R.id.txtUser);
        txtPass = findViewById(R.id.txtPass);
        btnLogin = findViewById(R.id.btnLogin);
        chk_login = findViewById(R.id.chk_login);
        SharedPreferences pre = getSharedPreferences("Profile_user",MODE_PRIVATE);
        txtUser.setText((pre.getString("user","")));
        txtPass.setText((pre.getString("pass","")));
        chk_login.setChecked((pre.getBoolean("check",false)));
        daott = new DAOTT(this);
        // hide and show password
        txtPass.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                final int Right=2;
                if(event.getAction()==MotionEvent.ACTION_UP){
                    if(event.getRawX()>=txtPass.getRight()-txtPass.getCompoundDrawables()[Right].getBounds().width()){
                        int selecttion = txtPass.getSelectionEnd();
                        if(passwordVisible){
                            //set drawble img
                            txtPass.setCompoundDrawablesRelativeWithIntrinsicBounds(0,0, R.drawable.ic_baseline_visibility_off_24,0);
                            //set pass hide text
                            txtPass.setTransformationMethod(PasswordTransformationMethod.getInstance());
                            passwordVisible =false;
                        }else{
                            //set drawble img
                            txtPass.setCompoundDrawablesRelativeWithIntrinsicBounds(0,0,R.drawable.ic_baseline_visibility_24,0);
                            // set pass visible
                            txtPass.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                            passwordVisible =true;
                        }
                        txtPass.setSelection(selecttion);
                        return true;
                    }
                }
                return false;
            }
        });
        // login
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = txtUser.getText().toString();
                String pass = txtPass.getText().toString();
                checkLogin(user,pass);
            }
        });

    }
    private void checkLogin(String user,String pass){

        if(user.isEmpty() && pass.isEmpty()){
            Toast.makeText(this, "Tài khoản và mật khẩu không được để trống", Toast.LENGTH_SHORT).show();
        }else{
            if(daott.checkLogin(user,pass)) {
                Toast.makeText(this, "Đăng nhập thành công", Toast.LENGTH_SHORT).show();
                rememberUser(user,pass,chk_login.isChecked());
                startActivity(new Intent(Login_Activity.this, MainActivity.class));
                finish();
            }
            else{
                Toast.makeText(this, "Tên đăng nhập hoặc mật khẩu không đúng", Toast.LENGTH_SHORT).show();
            }
        }
    }
    private void rememberUser(String user,String pass, boolean check){
        SharedPreferences preferences = getSharedPreferences("Profile_user",MODE_PRIVATE);
        SharedPreferences.Editor edit = preferences.edit();
        if(!check){
            edit.clear();
        }else{
            edit.putString("user",user);
            edit.putString("pass",pass);
            edit.putBoolean("check",check);
        }
        edit.commit();
    }

}