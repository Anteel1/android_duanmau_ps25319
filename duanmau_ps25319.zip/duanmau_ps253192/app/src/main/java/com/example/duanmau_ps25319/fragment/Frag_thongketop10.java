package com.example.duanmau_ps25319.fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.duanmau_ps25319.DAO.DAOThongke;
import com.example.duanmau_ps25319.R;
import com.example.duanmau_ps25319.adapter.Adapter_top10;
import com.example.duanmau_ps25319.adapter.SachAdapter;
import com.example.duanmau_ps25319.model.Thongke;

import java.util.ArrayList;

public class Frag_thongketop10 extends Fragment {
    Button btnadd,btnDelete;
    ListView listView;
    ArrayList<Thongke> lists;
    Adapter_top10 adapter_top10;
    DAOThongke daoThongke;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
       View v = inflater.inflate(R.layout.list_view,container,false);
       // anh xa
        listView = v.findViewById(R.id.list_view);
        btnadd = v.findViewById(R.id.btnYes);
        btnDelete = v.findViewById(R.id.btnNo);
        daoThongke = new DAOThongke(getContext());
        btnadd.setVisibility(ViewGroup.GONE);
        btnDelete.setVisibility(ViewGroup.GONE);
        loadData();
        return v;
    }
    private void loadData(){
        lists = daoThongke.getTop10();
        adapter_top10 = new Adapter_top10(getActivity(),this,lists);
        listView.setAdapter(adapter_top10);
    }
}
