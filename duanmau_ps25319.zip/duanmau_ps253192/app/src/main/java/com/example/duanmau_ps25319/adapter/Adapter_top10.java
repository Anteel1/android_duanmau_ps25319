package com.example.duanmau_ps25319.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.duanmau_ps25319.R;
import com.example.duanmau_ps25319.fragment.Frag_thongketop10;
import com.example.duanmau_ps25319.model.Thongke;

import java.util.ArrayList;

public class Adapter_top10 extends ArrayAdapter<Thongke> {
    private Context context;
    private ArrayList<Thongke>list;
    Frag_thongketop10 fragment;
    TextView tvTenSach,tvSoluong;
    public Adapter_top10(@NonNull Context context,Frag_thongketop10 fragment, ArrayList<Thongke> list){
        super(context,0,list);
        this.context = context;
        this.list = list;
        this.fragment = fragment;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View v = convertView;
        if(v==null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v =inflater.inflate(R.layout.thongke_top10,null);
        }
        final Thongke item = list.get(position);
        if(item != null){
            tvTenSach=v.findViewById(R.id.tvTenSach);
            tvSoluong=v.findViewById(R.id.tvSoluong);
            tvTenSach.setText(item.getTenSach());
            tvSoluong.setText(String.valueOf(item.getSoLuong()));
        }
        return v;
    }
}
