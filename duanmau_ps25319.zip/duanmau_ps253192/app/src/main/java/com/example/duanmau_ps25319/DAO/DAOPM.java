package com.example.duanmau_ps25319.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.duanmau_ps25319.database.sqlite;
import com.example.duanmau_ps25319.model.PhieuMuon;
import com.example.duanmau_ps25319.model.Sach;
import com.example.duanmau_ps25319.model.ThanhVien;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class DAOPM {
    private static sqlite sqlite;
    SimpleDateFormat dfm = new SimpleDateFormat("yyyy-MM-dd");
    public DAOPM(Context context){
        sqlite = new sqlite(context);
    }
    public ArrayList<PhieuMuon> getAll(){
        try{
            ArrayList<PhieuMuon> list = new ArrayList<>();
            SQLiteDatabase database =sqlite.getReadableDatabase();
            String sql ="Select * from PhieuMuon";
            Cursor cs = database.rawQuery(sql,null);
            cs.moveToFirst();
            while (!cs.isAfterLast()){
                list.add(new PhieuMuon(cs.getInt(0),cs.getInt(1),cs.getInt(2),
                        cs.getInt(3),cs.getFloat(4),dfm.parse(cs.getString(5)),
                        (cs.getInt(6))));
                cs.moveToNext();
            }
            database.close();
            cs.close();
            return list;
        }catch (Exception ex){
            ex.printStackTrace();
            return null;
        }
    }
    public boolean insert(PhieuMuon phieuMuon){
        SQLiteDatabase database = sqlite.getWritableDatabase();
        try{
            ContentValues contentValues = new ContentValues();
            contentValues.put("MaTV",phieuMuon.getMaTV());
            contentValues.put("MaSach",phieuMuon.getMaSach());
            contentValues.put("MaTT",phieuMuon.getMaTT());
            contentValues.put("Tienthue",phieuMuon.getTienThue());
            contentValues.put("Ngaythue",dfm.format(phieuMuon.getNgaythue()));
            contentValues.put("Ngaytra",(phieuMuon.getNgaytra()));
            long values =database.insert("PhieuMuon",null,contentValues);
            return (values>0);
        }catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
    public boolean updatePM(PhieuMuon phieuMuon){
        SQLiteDatabase database = sqlite.getWritableDatabase();
        database.beginTransaction();
        long values=-1;
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put("MaTV",phieuMuon.getMaTV());
            contentValues.put("MaSach",phieuMuon.getMaSach());
            contentValues.put("MaTT",phieuMuon.getMaTT());
            contentValues.put("Tienthue",phieuMuon.getTienThue());
            contentValues.put("Ngaythue",dfm.format(phieuMuon.getNgaythue()));
            contentValues.put("Ngaytra",(phieuMuon.getNgaytra()));
            values= database.update("PhieuMuon",contentValues,"MaPM =?",
                    new String[]{String.valueOf(phieuMuon.getMaPM())});
            database.setTransactionSuccessful();
        }catch (Exception ex){
            ex.printStackTrace();
            return false;
        }finally {
            database.endTransaction();
            return (values>0);
        }
    }
    public boolean deletePM(int maPM){
        SQLiteDatabase database = sqlite.getWritableDatabase();
        boolean check = false;
        try{
            database.delete("PhieuMuon","MaPM=?",new String[]{String.valueOf(maPM)});
            check = true;
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return check;
    }
}
