package com.example.duanmau_ps25319.fragment;

import static android.content.Context.MODE_PRIVATE;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.duanmau_ps25319.DAO.DAOPM;
import com.example.duanmau_ps25319.DAO.DAOSach;
import com.example.duanmau_ps25319.DAO.DAOTT;
import com.example.duanmau_ps25319.DAO.DAOTV;
import com.example.duanmau_ps25319.R;
import com.example.duanmau_ps25319.adapter.PhieuMuonAdapter;
import com.example.duanmau_ps25319.adapter.SachAdapter;
import com.example.duanmau_ps25319.adapter.ThanhVienAdapter;

import com.example.duanmau_ps25319.model.PhieuMuon;
import com.example.duanmau_ps25319.model.Sach;
import com.example.duanmau_ps25319.model.ThanhVien;
import com.example.duanmau_ps25319.model.ThuThu;
import com.example.duanmau_ps25319.views.MainActivity;


import java.text.SimpleDateFormat;
import java.util.ArrayList;


public class Frag_PhieuMuon extends Fragment {
    ListView listView;
    Spinner spinnerSach,spinnerThanhvien;
    Button btnOk,btnAdd,btnDelete,btnDialogDeleteYes,btnDialogDeleteNo;
    PhieuMuonAdapter adapter;
    SachAdapter sachAdapter;
    ThanhVienAdapter thanhVienAdapter;
    EditText txtNgaymuon;
    CheckBox txtNgaytra;
    TextView tvTienThue,tvThuThu,tvTitleDialog,tvDialogDelete;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    int maPM,maSach,maTV;
    View lastTouchView;
    DAOPM daopm;
    DAOSach daoSach;
    DAOTV daotv;
    ArrayList<PhieuMuon>list;
    PhieuMuon item;
    SharedPreferences preferences;
    String user;
    static DAOTT daott;
    ThuThu tt;
    int checkDatra;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.list_view,container,false);
        lastTouchView=new View(getActivity());
        btnAdd = v.findViewById(R.id.btnYes);
        btnDelete = v.findViewById(R.id.btnNo);
        daopm = new DAOPM(getActivity());
        daoSach = new DAOSach(getActivity());
        daotv= new DAOTV(getActivity());
        listView= v.findViewById(R.id.list_view);
        // share preference lay thong tin thu thu
        preferences= getActivity().getSharedPreferences("Profile_user", MODE_PRIVATE);
        user = preferences.getString("user","");
        daott = new DAOTT(getContext());
        tt = daott.getID(user);
        // set data
        loadData();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                lastTouchView.setBackgroundResource(0);
                view.setBackgroundResource(R.color.pink_1);
                lastTouchView =view;
                item = list.get(position);
                maPM=item.getMaPM();
            }
        });
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                item = list.get(position);
                maPM=item.getMaPM();
                openDialog(1);
                return false;
            }
        });
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            openDialog(0);
            }
        });
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                xoa(maPM);
            }
        });
        return v;
    }
    private void xoa(final int id){
        AlertDialog.Builder builder =new AlertDialog.Builder(getContext());
        LayoutInflater inflater =this.getLayoutInflater();
        View v = inflater.inflate(R.layout.dialog_exit,null);
        builder.setView(v);
        Dialog dialog = builder.create();
        dialog.show();
        tvTitleDialog =(TextView) v.findViewById(R.id.title_dialog);
        tvDialogDelete = (TextView)v.findViewById(R.id.content_dialog);
        btnDialogDeleteYes= v.findViewById(R.id.btnYes);
        btnDialogDeleteNo = v.findViewById(R.id.btnNo);
        tvTitleDialog.setText("Xóa phiếu mượn");
        tvDialogDelete.setText("Bạn đồng ý xóa phiếu mượn này chứ ?");
        btnDialogDeleteNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        btnDialogDeleteYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if( daopm.deletePM(maPM)){
                    Toast.makeText(getContext(), "Xóa thành công", Toast.LENGTH_SHORT).show();
                    loadData();
                    dialog.dismiss();
                }else{
                    Toast.makeText(getContext(), "Xóa thất bại", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
    protected void openDialog(final int type){
        AlertDialog.Builder builder =new AlertDialog.Builder(getContext());
        LayoutInflater inflater =this.getLayoutInflater();
        View v = inflater.inflate(R.layout.add_phieumuon,null);
        builder.setView(v);
        Dialog dialog = builder.create();
        dialog.show();
        tvTienThue = dialog.findViewById(R.id.tvTienThue);
        txtNgaymuon = dialog.findViewById(R.id.txtNgaymuon);
        txtNgaytra = dialog.findViewById(R.id.txtNgaytra);
        spinnerSach = dialog.findViewById(R.id.spinnerSach);
        spinnerThanhvien = dialog.findViewById(R.id.spinnerTv);
        tvThuThu = dialog.findViewById(R.id.tvThuThu);
        btnOk= dialog.findViewById(R.id.btnOk);
        // get ngay tra
        txtNgaytra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(txtNgaytra.isChecked()){
                    checkDatra = 1;
                }else{
                    checkDatra =0;
                }
            }
        });
        // set ten thu thu
        tvThuThu.setText(tt.getTenTT());
        // spinner sach
        ArrayList<Sach>listSach=daoSach.getAll();
        sachAdapter = new SachAdapter(getActivity(),listSach);
        spinnerSach.setAdapter(sachAdapter);
        // spinner thanh vien
        ArrayList<ThanhVien>listtv=daotv.getAll();
        thanhVienAdapter = new ThanhVienAdapter(getContext(),listtv);
        spinnerThanhvien.setAdapter(thanhVienAdapter);
        spinnerThanhvien.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                maTV= listtv.get(position).getMaTV();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        //spinner sach , set money cho textview tienthue
        spinnerSach.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                maSach = listSach.get(position).getMaSach();
                tvTienThue.setText(String.valueOf(listSach.get(position).getTienThue()));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        if(type !=0){
            btnOk.setText("Cập nhật phiếu mượn");
            tvTienThue.setText(String.valueOf(item.getTienThue()));
            txtNgaymuon.setText(sdf.format(item.getNgaythue()));
            spinnerSach.setSelection(item.getMaSach()-1);
            spinnerThanhvien.setSelection(item.getMaTV()-1);
            tvThuThu.setText(user);
            txtNgaytra.setChecked((item.getNgaytra()==1));
        }
        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    item = new PhieuMuon();
                    item.setMaSach(maSach);
                    item.setMaTV(maTV);
                    item.setMaTT(tt.getMaTT());
                    item.setTienThue(Float.parseFloat(tvTienThue.getText().toString()));
                    item.setNgaythue(sdf.parse(txtNgaymuon.getText().toString()));
                    item.setNgaytra(checkDatra);
                    if(validate()>0){
                        if(type==0){
                            // insert dialog
                            if (daopm.insert(item)) {
                                Toast.makeText(getContext(), "Thêm thành công", Toast.LENGTH_SHORT).show();dialog.dismiss();
                                loadData();
                                dialog.dismiss();
                            }else{
                                Toast.makeText(getContext(), "Thêm thất bại", Toast.LENGTH_SHORT).show();
                            }
                        }else {
                            // get id thanh vien
                            item.setMaPM(maPM);
                            if(daopm.updatePM(item)){
                                Toast.makeText(getContext(), "Cập nhật thành công", Toast.LENGTH_SHORT).show();
                                loadData();
                                dialog.dismiss();
                            }else{
                                Toast.makeText(getContext(), "Cập nhật thất bại", Toast.LENGTH_SHORT).show();
                            }
                        }

                    }
                }catch (Exception ex){
                    ex.printStackTrace();
                }
            }
        });
    }
    private int validate(){
        int check =1;
        if(txtNgaymuon.getText().length() ==0){
            Toast.makeText(getContext(), "Ngày mượn không được trống", Toast.LENGTH_SHORT).show();
            check =-1;
        }
        return check;
    }
    private void loadData(){
        list = daopm.getAll();
        adapter = new PhieuMuonAdapter(getActivity(),this,list);
        listView.setAdapter(adapter);
    }
}
