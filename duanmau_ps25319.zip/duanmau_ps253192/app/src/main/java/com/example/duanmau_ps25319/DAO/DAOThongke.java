package com.example.duanmau_ps25319.DAO;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.duanmau_ps25319.database.sqlite;
import com.example.duanmau_ps25319.model.Sach;
import com.example.duanmau_ps25319.model.Thongke;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DAOThongke {
    private Context context;
    private sqlite sqlite;
    DAOSach daoSach;
    SimpleDateFormat dfm = new SimpleDateFormat("yyyy-MM-dd");
    public DAOThongke (Context context){
        sqlite= new sqlite(context);
        daoSach = new DAOSach(context);
    }
    public ArrayList<Thongke> getTop10(){
        ArrayList<Thongke> list = new ArrayList<>();
        SQLiteDatabase sqLiteDatabase = sqlite.getReadableDatabase();
        try{
            String sql = "Select MaSach, Count(MaSach) as soLuong from PhieuMuon Group By MaSach Order By soLuong DESC Limit 10";
            Cursor cs = sqLiteDatabase.rawQuery(sql,null);
            cs.moveToFirst();
            while(!cs.isAfterLast()){
                list.add(new Thongke(daoSach.getTenSachtheoID(cs.getInt(0)),cs.getInt(1)));
                cs.moveToNext();
            }
            sqLiteDatabase.close();
            cs.close();
            return list;
        }catch (Exception exception){
            exception.printStackTrace();
            return null;
        }

    }
    public float getDoanhthu(String tungay, String denngay){
        String sql = "Select Sum(Tienthue) as doanhThu from PhieuMuon where Ngaythue between ? and ?";
        float tongtien = 0;
        SQLiteDatabase database = sqlite.getReadableDatabase();
        Cursor cs = database.rawQuery(sql,new String[]{tungay,denngay});
        cs.moveToFirst();
        if(cs.getCount()!=0){
            tongtien =(cs.getFloat(0));
        }
        cs.close();
        database.close();
        return tongtien;
    }
}
