package com.example.duanmau_ps25319.adapter;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.duanmau_ps25319.R;
import com.example.duanmau_ps25319.fragment.FragThanhVien;
import com.example.duanmau_ps25319.model.LoaiSach;
import com.example.duanmau_ps25319.model.ThanhVien;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class ThanhVienAdapter extends ArrayAdapter<ThanhVien> {
    private Context context;
    FragThanhVien fragment;
    private  ArrayList<ThanhVien> list;
    TextView txtName,txtDate;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    public ThanhVienAdapter(@NonNull Context context, FragThanhVien fragment, ArrayList<ThanhVien> list) {
        super(context, 0,list);
        this.context=context;
        this.list=list;
        this.fragment=fragment;
    }
    public ThanhVienAdapter(@NonNull Context context,ArrayList<ThanhVien> list) {
        super(context, 0,list);
        this.context=context;
        this.list=list;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View v = convertView;
        if(v==null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v =inflater.inflate(R.layout.thanhvien_item,null);
        }
        final ThanhVien item = list.get(position);
        if(item !=null){
            txtName = v.findViewById(R.id.txtName);
            txtName.setText(item.getHoTen());
            txtDate=v.findViewById(R.id.txtDate);
            txtDate.setText(sdf.format(item.getNamSinh()));
        }
        return v;
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View v = convertView;
        if(v==null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v =inflater.inflate(R.layout.thanhvien_item,null);
        }
        final ThanhVien item = list.get(position);
        if(item !=null){
            txtName = v.findViewById(R.id.txtName);
            txtName.setText(item.getHoTen());
            txtDate=v.findViewById(R.id.txtDate);
            txtDate.setText(sdf.format(item.getNamSinh()));
        }

        return v;
    }
}
