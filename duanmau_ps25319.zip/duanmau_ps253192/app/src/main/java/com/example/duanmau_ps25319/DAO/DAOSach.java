package com.example.duanmau_ps25319.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.duanmau_ps25319.database.sqlite;
import com.example.duanmau_ps25319.model.LoaiSach;
import com.example.duanmau_ps25319.model.Sach;

import java.util.ArrayList;

public class DAOSach {
    private static com.example.duanmau_ps25319.database.sqlite sqlite;
    public DAOSach(Context context){
        sqlite = new sqlite(context);
    }
    public String getTenSachtheoID(int id){
        String name ="";
        try{
            SQLiteDatabase database = sqlite.getReadableDatabase();
            Cursor cs = database.rawQuery("Select * from Sach where MaSach=?",new String[]{String.valueOf(id)});
            cs.moveToFirst();
            if(cs.getCount()!=0){
                name = cs.getString(1);
            }
            database.close();
            cs.close();
            return name;
        }catch (Exception exception){
            exception.printStackTrace();
            return "";
        }
    }
    public ArrayList<Sach> getAll (){
        try{
            ArrayList<Sach> list = new ArrayList<>();
            SQLiteDatabase database =sqlite.getReadableDatabase();
            String sql ="Select * from Sach";
            Cursor cs = database.rawQuery(sql,null);
            cs.moveToFirst();
            while (!cs.isAfterLast()){
                list.add(new Sach(cs.getInt(0),cs.getString(1),cs.getFloat(2),cs.getInt(3)));
                cs.moveToNext();
            }
            database.close();
            cs.close();
            return list;
        }catch (Exception ex){
            ex.printStackTrace();
            return null;
        }

    }
    public boolean insert(Sach sach){
        SQLiteDatabase database = sqlite.getWritableDatabase();
        try{
            ContentValues contentValues = new ContentValues();
            contentValues.put("TenSach",sach.getTenSach());
            contentValues.put("Tienthue",sach.getTienThue());
            contentValues.put("Maloai",sach.getMaLoai());
            long values =database.insert("Sach",null,contentValues);
            return (values>0);
        }catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
    public boolean updateSach(Sach sach){
        SQLiteDatabase database = sqlite.getWritableDatabase();
        database.beginTransaction();
        long values=-1;
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put("TenSach",sach.getTenSach());
            contentValues.put("Tienthue",sach.getTienThue());
            contentValues.put("Maloai",sach.getMaLoai());
            values= database.update("Sach",contentValues,"MaSach =?",
                    new String[]{String.valueOf(sach.getMaSach())});
            database.setTransactionSuccessful();

        }catch (Exception ex){
            ex.printStackTrace();
            return false;
        }finally {
            database.endTransaction();
            return (values>0);
        }
    }
    public boolean deleteLoaisach(int maSach){
        SQLiteDatabase database = sqlite.getWritableDatabase();
        boolean check = false;
        try{
            database.delete("Sach","MaSach=?",new String[]{String.valueOf(maSach)});
            check = true;
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return check;
    }
}
